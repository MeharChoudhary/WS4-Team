
using System;

using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Web.Models;

namespace Web.Controllers
{
    public class MeharController : Controller
    {
        public IActionResult ShowText()
        {
            return Content("Here is text - hit back to return. ");
        }
    
        public IActionResult ShowJSON()
        {
            return  Json(new {name="favorite quote", quote="This is my favorite quote."});
        }
    
        public IActionResult ShowHTML()
        {
            var h = "<!DOCTYPE html><html><body>An awesome quote. Note return path has to use the name of the controller." + 
            "<br><br> <a href='/Quote'>Go Back to Quotes</a></body></html>";
            return Content(h, "text/html");
        }

        public IActionResult ShowView()
        {
            
            return View();
        }

        public IActionResult ModelTest(int id)
        {
           
            var tempval = RetrunStudentDetails(id);
            var html = PrintFunction(tempval);
            return Content(html, "text/html");
        }

        public StudentModel RetrunStudentDetails(int id)
        {
            List<StudentModel> studentTempList=new List<StudentModel>();

             var student1= new StudentModel(){

                 StudentId=1,
                 StudentName="Mehar"                 
             };
             
             var student2= new StudentModel(){

                 StudentId=2,
                 StudentName="Aakash"                 
             };


             studentTempList.Add(student1);
             studentTempList.Add(student2);

                for (int i = 0; i < studentTempList.Count; i++)
                {
                    if(studentTempList[i].StudentId==id)
                    {
                        return studentTempList[i];

    
                    }
              

                }
            StudentModel studentView = new StudentModel();
            studentView.StudentId = 0;
            return studentView;

        }

        public string PrintFunction(StudentModel student){          

                 return student.StudentId +" "+ student.StudentName;                         
                 
        }
    }
}









    

    