using System;

namespace Web.Models
{
    public class StudentModel
    {        
        public int StudentId { get; set; }

        public string  StudentName{ get; set; }
        
    }
}